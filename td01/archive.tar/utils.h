#ifndef _UTILS_H_
#define _UTILS_H_

void print_list(int list[], int size);

#endif