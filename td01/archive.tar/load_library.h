//
// Created by appad on 2/28/2023.
//

#ifndef TD01_LOAD_LIBRARY_H
#define TD01_LOAD_LIBRARY_H
#include "sort.h"
void load_library(char *library_name);

void close_library();



#endif //TD01_LOAD_LIBRARY_H
